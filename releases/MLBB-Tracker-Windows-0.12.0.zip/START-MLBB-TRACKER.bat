@echo off
title MLBB Tracker
cd /d "%~dp0app"
set "PATH=%~dp0php;%PATH%"

if not exist .env copy .env.example .env >nul
findstr /C:"APP_KEY=base64" .env >nul 2>&1 || php artisan key:generate --force
php artisan migrate --force

echo.
echo   MLBB Tracker is starting - your browser will open at
echo   http://127.0.0.1:8000
echo   Keep this window open while you use the app. Close it to stop.
echo.
start "" http://127.0.0.1:8000
php artisan serve --host 127.0.0.1 --port 8000
