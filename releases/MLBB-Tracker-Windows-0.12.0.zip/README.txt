﻿MLBB TRACKER - Windows package
==============================

WHAT THIS IS
  The full MLBB Tracker web app (React front end + Laravel API + database)
  bundled with its own PHP runtime. No installation, no PHP/Composer/Node
  required.

HOW TO RUN
  1. Double-click  START-MLBB-TRACKER.bat
  2. Your browser opens http://127.0.0.1:8000 automatically.
  3. Keep the black window open while using the app; closing it stops the
     server.

REQUIREMENTS
  - Windows 10/11 (64-bit)
  - Internet connection for live hero data and account sign-in

NOTES
  - Your data lives in app\database\database.sqlite (this folder).
  - Uninstall = delete this folder.
  - Unofficial fan project. Not affiliated with Moonton.
