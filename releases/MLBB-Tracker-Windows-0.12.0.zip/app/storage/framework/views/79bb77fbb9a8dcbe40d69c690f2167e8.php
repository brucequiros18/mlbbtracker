<?php echo $indexHtml; ?>

<?php /**PATH D:\projs\project1\server\resources\views/spa.blade.php ENDPATH**/ ?>