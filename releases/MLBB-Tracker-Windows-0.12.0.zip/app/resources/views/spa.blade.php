{!! $indexHtml !!}
